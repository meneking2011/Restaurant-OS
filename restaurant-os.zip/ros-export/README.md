# RestaurantOS — Deployment & Setup Guide

A full-stack restaurant management platform with a public-facing storefront, online ordering, reservations, and a complete admin panel. Powered by **React + Vite** on the front end and **Firebase** (Auth + Firestore + Hosting) as the back end.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Firebase Project Setup](#2-firebase-project-setup)
3. [Clone & Install Dependencies](#3-clone--install-dependencies)
4. [Configure Environment Variables](#4-configure-environment-variables)
5. [Run Locally](#5-run-locally)
6. [Build for Production](#6-build-for-production)
7. [Deploy to Firebase Hosting](#7-deploy-to-firebase-hosting)
8. [Apply Firestore Security Rules](#8-apply-firestore-security-rules)
9. [Connect a Custom Domain](#9-connect-a-custom-domain)
10. [First Login & Onboarding](#10-first-login--onboarding)
11. [Project Structure](#11-project-structure)

---

## 1. Prerequisites

| Tool | Minimum version | Install |
|------|----------------|---------|
| Node.js | 20 LTS or higher | https://nodejs.org |
| npm | comes with Node | — |
| Git | any | https://git-scm.com |
| Firebase CLI | latest | `npm install -g firebase-tools` |

Verify your environment:

```bash
node -v      # v20.x.x or higher
npm -v       # 10.x.x or higher
firebase --version
```

---

## 2. Firebase Project Setup

### 2a. Create a Firebase project (skip if you already have one)

1. Go to **https://console.firebase.google.com**
2. Click **Add project** → give it a name → Continue
3. (Optional) Disable Google Analytics if you don't need it → **Create project**

### 2b. Enable Authentication

1. In the Firebase Console sidebar → **Build → Authentication**
2. Click **Get started**
3. Under **Sign-in method**, enable **Email/Password** → Save

### 2c. Enable Firestore

1. Sidebar → **Build → Firestore Database**
2. Click **Create database**
3. Choose **Start in production mode** (you'll apply the correct rules in Step 8)
4. Pick a Cloud Firestore location closest to your users → Enable

### 2d. Register a Web App & get your config

1. Sidebar → **Project Overview** (home icon) → click the **`</>`** (Web) icon
2. Give the app a nickname (e.g. `restaurant-os-web`) → **Register app**
3. You'll see a code block like:

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.firebasestorage.app",
  messagingSenderId: "123456789",
  appId: "1:123:web:abc123"
};
```

Keep this page open — you'll paste these values into `.env` in Step 4.

### 2e. Enable Firebase Hosting

1. Sidebar → **Build → Hosting**
2. Click **Get started** → follow the wizard (you can skip the CLI steps shown there; we handle them below)

---

## 3. Clone & Install Dependencies

```bash
# If you downloaded the ZIP, extract it and navigate into the folder:
cd restaurant-os

# Install all dependencies
npm install
```

This installs React, Vite, Firebase SDK, Tailwind CSS, Radix UI, Zustand, Recharts, and every other dependency listed in package.json.

---

## 4. Configure Environment Variables

```bash
# Copy the example file
cp .env.example .env
```

Open `.env` in any text editor and fill in the values from Step 2d:

```env
VITE_FIREBASE_API_KEY=AIza...
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123:web:abc123
```

> **Security note:** These values are bundled into the client-side JavaScript and are safe to include — Firebase Web API keys are not secret. Access control is enforced by Firestore Security Rules (Step 8).

Also update `.firebaserc` with your actual project ID:

```json
{
  "projects": {
    "default": "your-project-id"
  }
}
```

---

## 5. Run Locally

```bash
npm run dev
```

The app opens at **http://localhost:5173**

- Public storefront: `http://localhost:5173/`
- Admin panel: `http://localhost:5173/admin`
- Admin login: `http://localhost:5173/admin/login`

---

## 6. Build for Production

```bash
npm run build
```

Output goes to the `dist/` folder. You can preview it locally:

```bash
npm run preview
# Opens at http://localhost:4173
```

---

## 7. Deploy to Firebase Hosting

### Option A — Interactive login (easiest for a one-off deploy)

```bash
# Log in to Firebase with your Google account
firebase login

# Deploy hosting + Firestore rules in one command
firebase deploy

# Or hosting only:
firebase deploy --only hosting
```

Your site will be live at:
- `https://your-project-id.web.app`
- `https://your-project-id.firebaseapp.com`

### Option B — CI/CD with a Service Account (GitHub Actions, automated pipelines)

1. In Firebase Console → **Project Settings → Service accounts**
2. Click **Generate new private key** → download the JSON file
3. Store the entire JSON content as a secret in your CI environment, e.g. `GOOGLE_APPLICATION_CREDENTIALS_JSON`
4. In your deploy script:

```bash
#!/usr/bin/env bash
set -e

SA_FILE=$(mktemp /tmp/firebase-sa-XXXXXX.json)
trap 'rm -f "$SA_FILE"' EXIT

echo "$GOOGLE_APPLICATION_CREDENTIALS_JSON" > "$SA_FILE"

npm run build
GOOGLE_APPLICATION_CREDENTIALS="$SA_FILE" firebase deploy --only hosting --non-interactive
```

---

## 8. Apply Firestore Security Rules

This is **required** before going live. Without these rules, all Firestore data is publicly readable and writable.

### Option A — Deploy via CLI (recommended)

```bash
firebase deploy --only firestore:rules
```

This reads `firestore.rules` from the project root and applies it automatically.

> **Note:** If you get a permission error, your service account may not have the `Service Usage API` permission. Use Option B in that case.

### Option B — Paste in Firebase Console

1. Go to **Firebase Console → Firestore Database → Rules**
2. Replace the entire content with the following rules, then click **Publish**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /owners/{uid} {
      allow read, create: if request.auth != null && request.auth.uid == uid;
      allow update, delete: if false;
    }
    match /restaurants/{restaurantId} {
      allow read: if restaurantId == "default"
        || (request.auth != null
            && get(/databases/$(database)/documents/owners/$(request.auth.uid)).data.restaurantId == restaurantId);
      allow write: if request.auth != null
        && get(/databases/$(database)/documents/owners/$(request.auth.uid)).data.restaurantId == restaurantId;
    }
  }
}
```

**What these rules do:**
- `owners/{uid}` — Only the signed-in user can read/create their own owner record. Nobody can modify or delete it.
- `restaurants/{restaurantId}` — The `"default"` restaurant (your public storefront) is publicly readable by anyone. Writes are restricted to the authenticated owner of that restaurant.

---

## 9. Connect a Custom Domain

1. Firebase Console → **Build → Hosting**
2. Select your site → click **Add custom domain**
3. Enter your domain (e.g. `restaurant-os.com`) → **Continue**
4. Firebase will give you two **A records** (IP addresses) to add to your DNS provider
5. Add those A records at your domain registrar (GoDaddy, Namecheap, Cloudflare, etc.)
6. Click **Verify** in Firebase Console — DNS propagation can take up to 24 hours
7. Firebase automatically provisions and renews an SSL certificate once the domain is verified

---

## 10. First Login & Onboarding

1. Open `https://your-domain.com/admin/login`
2. Click **Sign Up** and create your owner account with an email and password
3. The **first account ever created** in this Firebase project automatically claims the `"default"` restaurant — this is the storefront that public visitors see
4. You're taken directly to the Admin Dashboard
5. Start customising: **Admin → Business Details** sets your restaurant name, contact info, and hours. **Admin → Website** controls the look and feel. Everything saves to Firestore in real time

> Subsequent signups (if you share the admin URL) are provisioned as separate, fully isolated tenants — their data never mixes with yours.

---

## 11. Project Structure

```
restaurant-os/
├── src/
│   ├── admin/
│   │   ├── components/        # ConfirmDialog, PrintReceiptModal, StatCard
│   │   ├── layout/            # AdminLayout, AdminSidebar
│   │   └── pages/             # All admin panel pages (Dashboard, Orders, Reservations, …)
│   ├── components/
│   │   ├── layout/            # Navbar, Footer, HamburgerMenu, Layout
│   │   ├── sections/          # Homepage sections (Hero, Featured Dishes, CTA, …)
│   │   └── ui/                # Full Shadcn/Radix UI component library
│   ├── data/
│   │   └── mockData.ts        # Seed data shown before any real data is saved
│   ├── hooks/                 # use-mobile, use-toast
│   ├── lib/
│   │   ├── auth.tsx           # Firebase Auth helpers + first-owner onboarding logic
│   │   ├── firebase.ts        # Firebase app init (reads VITE_* env vars)
│   │   ├── tenantSync.ts      # Zustand ↔ Firestore two-way sync
│   │   └── utils.ts           # cn() utility
│   ├── pages/                 # Public-facing pages (Home, Menu, Checkout, Reservations, …)
│   ├── store/
│   │   ├── cartStore.ts       # Shopping cart state (Zustand)
│   │   └── restaurantStore.ts # All restaurant config & content state (Zustand)
│   ├── types/
│   │   └── restaurant.ts      # TypeScript interfaces for the entire data model
│   └── utils/                 # colorUtils, formatCurrency, sectionMedia, cn
├── public/                    # Static assets (favicon, og image, robots.txt)
├── .env.example               # Copy to .env and fill in Firebase config
├── .firebaserc                # Firebase project alias
├── firebase.json              # Hosting + Firestore rules config
├── firestore.rules            # Firestore security rules
├── index.html                 # HTML entry point
├── package.json               # Dependencies & npm scripts
├── tsconfig.json              # TypeScript config
└── vite.config.ts             # Vite build config
```

---

## Common Commands Reference

```bash
npm install          # Install all dependencies
npm run dev          # Start dev server at http://localhost:5173
npm run build        # Build for production → dist/
npm run preview      # Preview the production build locally
npm run typecheck    # Run TypeScript type checking
firebase login       # Authenticate Firebase CLI
firebase deploy      # Deploy hosting + Firestore rules
firebase deploy --only hosting         # Hosting only
firebase deploy --only firestore:rules # Firestore rules only
```
